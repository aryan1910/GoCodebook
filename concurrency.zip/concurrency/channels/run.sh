for i in {1..100}
do
   go run main.go
done
